Nexus™ Developer Automation Superpack
====================================
Thank you for supporting independent open-source software!

Tools included:
1. nexus_email_guardian.py   - IMAP spam cleaner & 2FA protector
2. nexus_whatsapp_bot_starter.py - FastAPI WhatsApp business bot
3. nexus_b2b_lead_scraper.py - DNS MX record gatekeeper & verifier

Created with pride by Deven Pawaray & Nexus AI.
Support & Questions: devenpawaray@gmail.com | WhatsApp: +230 58169420
