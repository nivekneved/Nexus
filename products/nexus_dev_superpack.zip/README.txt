Nexus™ Anti-SaaS Developer Arsenal & Superpack
===============================================
Thank you for supporting independent, open-source and self-hosted software!

Tools included in this archive:
1. nexus_email_guardian.py           - IMAP spam cleaner & 2FA protector
2. nexus_whatsapp_bot_starter.py     - FastAPI conversational WhatsApp business bot
3. nexus_b2b_lead_scraper.py         - DNS MX record gatekeeper & verifier
4. nexus_mcb_recon.py                - MCB statement & Juice PDF reconciler (Mauritius B2B)
5. nexus_invoice_pdf_extractor.py    - PDF invoice line item & 15% VAT extractor
6. nexus_crypto_price_alert.py       - Self-hosted crypto feed & threshold daemon
7. nexus_seo_keyword_serp_tracker.py - Local Google search ranking tracker

Perpetual Commercial Rights:
You own these scripts permanently. Zero telemetry, zero recurring subscriptions.
Run them locally on your machine, server, or VPS.

Created with pride by Deven Pawaray & Nexus AI.
Support & Inquiries: devenpawaray@gmail.com | WhatsApp: +23058169420
